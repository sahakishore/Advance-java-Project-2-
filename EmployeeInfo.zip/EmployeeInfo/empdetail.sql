create table empdetail(empno number(20), ename varchar2(4000), salary number(20));

